package com.taxis99.zendesk.model;

public enum UserRole {
  END_USER, AGENT, ADMIN
}
