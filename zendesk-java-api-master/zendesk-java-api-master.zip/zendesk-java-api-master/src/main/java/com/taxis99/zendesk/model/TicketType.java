package com.taxis99.zendesk.model;

public enum TicketType {
  PROBLEM, INCIDENT, QUESTION, TASK
}