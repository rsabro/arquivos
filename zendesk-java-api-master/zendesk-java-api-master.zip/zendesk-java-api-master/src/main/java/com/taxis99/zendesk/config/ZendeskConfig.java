package com.taxis99.zendesk.config;

public interface ZendeskConfig {
  String getAuth();
  String getSubdomain();
  int getConnTimeout();
}
