package com.taxis99.zendesk.model;

public enum TicketPriority {
  URGENT, HIGH, NORMAL, LOW
}
