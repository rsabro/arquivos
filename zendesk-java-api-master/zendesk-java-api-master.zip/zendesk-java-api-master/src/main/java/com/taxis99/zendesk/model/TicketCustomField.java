package com.taxis99.zendesk.model;

public class TicketCustomField {
  private long id;
  private String value;

  public long getId() {
    return id;
  }

  public String getValue() {
    return value;
  }

  public void setId(long id) {
    this.id = id;
  }

  public void setValue(String value) {
    this.value = value;
  }
}
